/*
	Author: Elizabeth Li
	Date: 3/11/19
	This is the shearSort.c file. Here is where all of the operations take place.
	In this file, running the code will allow you to read text files containing a nxn grid
	of integers and using pthreads and conditional variables, we will be able to implement the ShearSort 
	Algorithm and sort the array in an updated order. Thanks to the usage of threads and conditional variables,
	we can call and output each phase of the sorting algorithm taking place.
*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <ctype.h>
pthread_mutex_t mu1 = PTHREAD_MUTEX_INITIALIZER; 
pthread_cond_t c1 = PTHREAD_COND_INITIALIZER;   
int n;
int phase = 1;
int threadCount = 0;
int rows = 0;
int** shearSortArray;

struct thread
{
	int id;
};
void outputTheArray();

/*
    Part of the shearsort algorithm. Sorts the values by rows
	in reverse order, taking in an integer value as a parameter
	called by the thread as the threads iterate through
	the phase number. Updates the array and since it's void
	it doesn't return anything
*/
void rowReverseSort(int i)
{	
	int j, k;
    for(j=0;j<n-1;j++)
    {
        for(k=0;k<n-j-1;k++)
        {
            if(shearSortArray[i][k]<shearSortArray[i][k+1])
            {
                int temp=shearSortArray[i][k];
                shearSortArray[i][k]=shearSortArray[i][k+1];
                shearSortArray[i][k+1]=temp;
            }
        }
    }
}
/*
	Part of the shearsort algorithm. Sorts the values by rows
	in ascending order, taking in an integer value as a parameter
	called by the thread as the threads iterate through
	the phase number. Updates the array and since it's void
	it doesn't return anything
*/

void rowSort(int i)
{
	int j, k;
    for(j=0;j<n-1;j++)
    {
        for(k=0;k<n-j-1;k++)
        {
            if(shearSortArray[i][k]>shearSortArray[i][k+1])
            {
                int temp=shearSortArray[i][k];
                shearSortArray[i][k]=shearSortArray[i][k+1];
                shearSortArray[i][k+1]=temp;
            }
        }
    }
}
/*
	 Part of the shearsort algorithm. Sorts the values by columns
	in ascending order, taking in an integer value as a parameter
	called by the thread as the threads iterate through
	the phase number. Updates the array and since it's void
	it doesn't return anything
*/

void colSort(int i)
{
	int j, k;
    for(j=0;j<n-1;j++)
    {
        for(k=0;k<n-j-1;k++)
        {
            if(shearSortArray[k][i]>shearSortArray[k+1][i])
            {
                int temp=shearSortArray[k][i];
                shearSortArray[k][i]=shearSortArray[k+1][i];
                shearSortArray[k+1][i]=temp;
            }
        }
    }
}
/*
	Called by the threads and takes in the thread id as an input. If the phase is odd,
	it will sort by rows and depending on the iteration position of the for loop, if the
	iteration is even, we will call rowReverseSort. Otherwise, rowSort. If the phase is EVEN,
	it will call column sort. Every time after it sorts, it will print the updated array
	and phase number. It takes in the parameter that is the id for the thread.
*/
void* shearSort(void *id)
{
	struct thread *thrId = (struct thread*) id; 
	 int j, k;
	while(phase <= n+1)
	{	
		if(phase%2 == 1)
		{	
			//Sorts rows by ascending or descending order. Ascending for regular, descending for reverse
			//Checks if the id of the thread is even. If so, we sort by rows in ascending order
			   if(thrId->id % 2 ==0)
			    {	
			    	//Sort rows
			    	 for(j=0;j<n-1;j++)
   					 {
      				  for(k=0;k<n-j-1;k++)
     				   {
        			    if(shearSortArray[thrId->id][k]>shearSortArray[thrId->id][k+1])
        			    {
          			      int temp=shearSortArray[thrId->id][k];
             			  shearSortArray[thrId->id][k]=shearSortArray[thrId->id][k+1];
                		  shearSortArray[thrId->id][k+1]=temp;
            			}	
        			   }
   					 }
			   		
			   		pthread_mutex_lock(&mu1);
			   		threadCount++;
			   		//If we are done with the threads for this phase, update the phase number and print the phase
			   		if(n == threadCount)
			   		{
			   				printf("Phase: %d\n", phase);
							outputTheArray();
							phase++;
							threadCount=0;
							//To ensure that we do not print more than the required phases
							if(phase > n+1)
							{	
								 exit(0);
							}
							 pthread_mutex_unlock(&mu1);
							 pthread_cond_broadcast(&c1);
			   		} 
			   		//If it's not the thread's turn, wait
			   		else
			   		{
			   			pthread_cond_wait(&c1, &mu1);
			   			pthread_mutex_unlock(&mu1);
			   		}
			    } 
			    //If the thread is odd, we sort in descending order
			   if(thrId->id % 2 == 1)
				{	
					//Sorts rows in reverse
				  
				   	for(j=0;j<n-1;j++)
   					 {
     				   for(k=0;k<n-j-1;k++)
        				{
         			   if(shearSortArray[thrId->id][k]<shearSortArray[thrId->id][k+1])
          				  {
             			   int temp=shearSortArray[thrId->id][k];
                		   shearSortArray[thrId->id][k]=shearSortArray[thrId->id][k+1];
                		   shearSortArray[thrId->id][k+1]=temp;
           				 }
        				}
   					 }
				   	pthread_mutex_lock(&mu1);
				    threadCount++;	
			   		if(n == threadCount)
			   		{
			   				printf("Phase: %d\n", phase);
							outputTheArray();
							phase++;
							threadCount=0;
							if(phase > n+1)
							{	
								 exit(0);
							}
							pthread_mutex_unlock(&mu1);
							pthread_cond_broadcast(&c1);
			   		} 
			   		else
			   		{
			   			pthread_cond_wait(&c1, &mu1);
			   			pthread_mutex_unlock(&mu1);
			   		}
			}
		}	
		//Even phases sort the columns
		if(phase%2 == 0)
		{		
				//Sort columns	
				for(j=0;j<n-1;j++)
    			{
     			   for(k=0;k<n-j-1;k++)
       				{
           			 if(shearSortArray[k][thrId->id]>shearSortArray[k+1][thrId->id])
           			 {
                		int temp=shearSortArray[k][thrId->id];
                		shearSortArray[k][thrId->id]=shearSortArray[k+1][thrId->id];
                		shearSortArray[k+1][thrId->id]=temp;
            		 }
        			}
    			}
				pthread_mutex_lock(&mu1);
				threadCount++;
				
				if(n == threadCount)
			   	{
			   		printf("Phase: %d\n", phase);
					outputTheArray();
					phase++;
										
					if(phase > n+1)
					{	
						 exit(0);
					}
					threadCount=0;
					pthread_cond_broadcast(&c1); 
					pthread_mutex_unlock(&mu1);
			   	} 
			   	else
			   	{
			   		pthread_cond_wait(&c1, &mu1); 
			   		pthread_mutex_unlock(&mu1);
			   	}
		}
	}
}
/*
	Take in the same input file twice. Once doing so, it allocates everything into the shearSort array and
	creates the threads based off the size of N. The threads will call shearSort method and send in the id
	of the threads, sorting each phase accordingly and printing out each phase until it hits n+1 number of phases
*/
int main()
{
	int i=0, createdThread,
	j= 0, symbol  = 0,
    counter = 0,
    temp = 0;
	
	//Insert text file
	FILE *importFile;	
	importFile = fopen("test4.txt", "r");
	
	//Error check
    if (importFile == NULL)
	{
		printf("Error Reading File\n");
		exit(0);
	}
	//Getting the size of matrix
    do
    {     
            if(fscanf(importFile, "%d", &temp)){
            	counter++;
            }
            symbol = fgetc(importFile);
            if (symbol == '\n' || feof(importFile))
            {
                rows++;
            }
    }
    while (symbol != EOF);
    printf("The file contains %d  variables.\n", counter);
    //Check to see if it's a matrix
    if(counter == 0)
    {
    	printf("Please enter a valid file.\n");
    	return 0;
    }
    if(counter/rows != rows)
    {
    	printf("Number of rows and columns are not equal. Try again.\n");
    	return 0;
    }
    
    fclose(importFile);
   	FILE *importFile2;	
   	//Insert textfile AGAIN
    importFile2 = fopen("test4.txt","r");
    
    	if (importFile == NULL)
		{
			printf("Error Reading File\n");
			exit(0);
		}

		n = rows;
		printf("n: %d\n",n);
	    struct thread threadId[n];
		pthread_t t[n];
		shearSortArray = malloc(rows*sizeof(int*));
		for(i= 0;i <n;i++)
		{
		  shearSortArray[i]=(int*)malloc(n*sizeof(int));
		}
    	
    	for (i = 0; i < n; i++)
		{
			for(j = 0; j < n; j++)
			{ 
				fscanf(importFile2, "%d,", &shearSortArray[i][j]);
			}
		}	
		fclose(importFile2);
		printf("Our initial Array\n");
		outputTheArray();

		for (i = 0; i < n; i++)
		{
			threadId[i].id = i;
			pthread_create(&t[i], NULL, shearSort, &threadId[i]);
		}
		for (i = 0; i < n; i++)
		{
			pthread_join(t[i], NULL);
		}
 		 return 0;
}
/*
	Prints out the current version of shearSortArray, taking
	in the array as an input. Since it's void, it doesn't
	return anything.
*/
void outputTheArray()
{
	int i, j;
	for (i=0;i<n;i++)
	{
		for (j=0; j<n; j++)
		{ 
		  printf("%d ",shearSortArray[i][j]);
		}
		printf("\n");
	}
}




